<?php 
	header("Location: ./www/login.html");
?>